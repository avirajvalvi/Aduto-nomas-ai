package com.example.autovideo

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

data class Field(val key: String, val label: String, val secret: Boolean, val default: String)

val FIELDS = listOf(
    Field("gemini_key", "Gemini API Key", true, ""),
    Field("gemini_model", "Gemini मॉडल", false, "gemini-2.5-flash"),
    Field("el_key", "ElevenLabs API Key", true, ""),
    Field("el_voice", "ElevenLabs Voice ID", false, ""),
    Field("heygen_key", "HeyGen API Key", true, ""),
    Field("heygen_avatar", "HeyGen Avatar ID", false, ""),
    Field("yt_client_id", "YouTube Client ID", false, ""),
    Field("yt_client_secret", "YouTube Client Secret", true, ""),
    Field("yt_refresh", "YouTube Refresh Token", true, ""),
    Field("yt_privacy", "YouTube प्राइवेसी (private / unlisted / public)", false, "private"),
    Field("language", "स्क्रिप्ट की भाषा", false, "हिंदी")
)

val REQUIRED = listOf(
    "gemini_key", "el_key", "el_voice", "heygen_key", "heygen_avatar",
    "yt_client_id", "yt_client_secret", "yt_refresh"
)

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val prefs = app.getSharedPreferences("settings", Context.MODE_PRIVATE)

    val logs = mutableStateListOf<String>()
    var running by mutableStateOf(false)
    var resultLink by mutableStateOf("")

    fun load(): Map<String, String> =
        FIELDS.associate { it.key to (prefs.getString(it.key, it.default) ?: it.default) }

    fun save(values: Map<String, String>) {
        val e = prefs.edit()
        values.forEach { (k, v) -> e.putString(k, v.trim()) }
        e.apply()
    }

    fun start(url: String) {
        if (running) return
        val s = load()
        val missing = REQUIRED.filter { s[it].isNullOrBlank() }
        logs.clear()
        resultLink = ""
        if (missing.isNotEmpty()) {
            logs.add("पहले सेटिंग्स में सभी API की भरें।")
            return
        }
        running = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val pipeline = Pipeline(s, getApplication<Application>().cacheDir) { logs.add(it) }
                val link = pipeline.run(url)
                logs.add("तैयार! वीडियो: $link")
                resultLink = link
            } catch (e: Exception) {
                logs.add("फेल हुआ: ${e.message}")
            } finally {
                running = false
            }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // वीडियो बनते समय स्क्रीन चालू रहे
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val sharedText = intent?.getStringExtra(Intent.EXTRA_TEXT).orEmpty()
        val sharedUrl = Regex("https?://\\S+").find(sharedText)?.value.orEmpty()

        setContent { App(sharedUrl) }
    }
}

@Composable
fun App(initialUrl: String, vm: AppViewModel = viewModel()) {
    var screen by remember { mutableStateOf(0) }
    MaterialTheme {
        Surface(Modifier.fillMaxSize()) {
            Column(Modifier.fillMaxSize().padding(16.dp)) {
                Row(Modifier.fillMaxWidth()) {
                    Text("ऑटो वीडियो", style = MaterialTheme.typography.headlineSmall)
                    Spacer(Modifier.weight(1f))
                    TextButton(onClick = { screen = if (screen == 0) 1 else 0 }) {
                        Text(if (screen == 0) "सेटिंग्स" else "वापस")
                    }
                }
                if (screen == 0) {
                    Home(vm, initialUrl)
                } else {
                    SettingsScreen(vm) { screen = 0 }
                }
            }
        }
    }
}

@Composable
fun Home(vm: AppViewModel, initialUrl: String) {
    var url by remember { mutableStateOf(initialUrl) }
    val ctx = LocalContext.current
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
            value = url,
            onValueChange = { url = it },
            label = { Text("Reddit लिंक पेस्ट करें") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = { vm.start(url.trim()) },
            enabled = !vm.running && url.contains("reddit.com"),
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (vm.running) "बन रहा है..." else "वीडियो बनाओ")
        }
        if (vm.running) LinearProgressIndicator(Modifier.fillMaxWidth())
        if (vm.resultLink.isNotEmpty()) {
            Button(
                onClick = { ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(vm.resultLink))) },
                modifier = Modifier.fillMaxWidth()
            ) { Text("YouTube पर खोलें") }
        }
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(vm.logs) { Text(it, style = MaterialTheme.typography.bodyMedium) }
        }
    }
}

@Composable
fun SettingsScreen(vm: AppViewModel, onDone: () -> Unit) {
    val values = remember { mutableStateMapOf<String, String>().apply { putAll(vm.load()) } }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        FIELDS.forEach { f ->
            OutlinedTextField(
                value = values[f.key] ?: "",
                onValueChange = { values[f.key] = it },
                label = { Text(f.label) },
                singleLine = true,
                visualTransformation = if (f.secret) PasswordVisualTransformation() else VisualTransformation.None,
                modifier = Modifier.fillMaxWidth()
            )
        }
        Button(onClick = { vm.save(values); onDone() }, modifier = Modifier.fillMaxWidth()) {
            Text("सेव करें")
        }
    }
}
